//
//  MYPerson.m
//  sington_base
//
//  Created by 谢鑫 on 2019/8/21.
//  Copyright © 2019 Shae. All rights reserved.
//

#import "MYPerson.h"

@implementation MYPerson
static id _instance;
+ (instancetype)sharedInstance{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _instance=[[self alloc]init];;
    });
    return _instance;
}
+ (instancetype)allocWithZone:(struct _NSZone *)zone{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _instance=[super allocWithZone:zone];
    });
    return _instance;
}
-(id)copyWithZone:(NSZone*)zone{
    return _instance;
}
@end
