//
//  main.m
//  sington_base
//
//  Created by 谢鑫 on 2019/8/21.
//  Copyright © 2019 Shae. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MYPerson.h"
#import "MYStudent.h"
int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // insert code here...
        NSLog(@"Hello, World!");
        MYPerson *person1=[MYPerson sharedInstance];
        MYPerson *person2=[[MYPerson alloc]init];
        MYPerson *person3=[person1 copy];
        NSLog(@"person1:%p, person2:%p, person3:%p",person1,person2,person3);
        
        MYStudent *student1=[MYStudent sharedInstance];
        MYStudent *student2=[[MYStudent alloc]init];
        MYStudent *student3=[student1 copy];
        NSLog(@"student1:%p, student2:%p, student3:%p",student1,student2,student3);
    }
    return 0;
}
